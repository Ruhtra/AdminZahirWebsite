-- AlterTable
ALTER TABLE "Profiles" ADD COLUMN     "imageName" TEXT;
